
import SideMenuDesktop from "./SideMenuDesktop";

const JobsList = () => {
  return (
    <div>
      <div className="bg-gray-50">
        <SideMenuDesktop />
      </div>
    </div>
  );
};

export default JobsList;
