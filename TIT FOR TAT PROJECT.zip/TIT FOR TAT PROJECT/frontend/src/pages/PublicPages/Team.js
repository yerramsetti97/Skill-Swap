
import { useLocation, Link } from "react-router-dom";


const Team = () => {
  const { pathname } = useLocation();
  const url = "/client/team";
  const url2 = "/freelancer/team";
  return (
    <div>
      <div
        className={
          pathname.includes(url) || pathname.includes(url2)
            ? "p-8 bg-white dark:bg-gray-800 rounded-lg shadow"
            : "p-8 bg-white dark:bg-gray-800 rounded-lg shadow  mt-28 lg:mt-16"
        }
      >
        <p className="text-center text-3xl font-bold text-gray-800 dark:text-white">
          TitForTat team
        </p>
        <p className="text-center mb-12 text-xl font-normal text-gray-500 dark:text-gray-200">
          Meat the Team behind TitforTat
        </p>
       
      </div>
    </div>
  );
};

export default Team;
